#!/bin/bash
srun ./wcd -m input.in -t 2
